package app.model;

/** Phân loại giao dịch để phục vụ ghi sổ và báo cáo. */
public enum TxnType {
    INCOME,
    EXPENSE,
    TRANSFER_IN,
    TRANSFER_OUT
}
