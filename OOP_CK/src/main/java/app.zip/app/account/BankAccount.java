package app.account;

/** Tài khoản ngân hàng. */
public class BankAccount extends Account {
    public BankAccount(String name) {
        super(name, "Ngân hàng");
    }
}
